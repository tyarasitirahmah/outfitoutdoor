<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

define( 'FS_METHOD', 'direct' );

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'outfitoutdoor' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'm2@VmH`C7D?+vlfk]k@-7P;HST~xL/6}]NoIU}gX%d-mtIBT{iw[QM*2PDVGGCnv' );
define( 'SECURE_AUTH_KEY',  '}9iew[?0%>&noBLMu`|4f7ebv5B?|$4.FN `NgShEN{C1:=7KT;g%A-4!tzx_EJ1' );
define( 'LOGGED_IN_KEY',    'Ny40jyBB3i-$cTZpf:Y8W/zJ8kd_g]~^JA[u(!z}*r|9N6:^?OLA!rn+bY9I!#A ' );
define( 'NONCE_KEY',        'a19#eD4#mg:^b%^0d:oL,`W9?L<p*Re(9 E1@DW.VL4E+zlVvIqC=[pyfA: tGn[' );
define( 'AUTH_SALT',        'gjOxrl*_XNV[:*GJM[,1/>#k8_j1oC..XT}V3.(2AAH{JO_LC-q[t<S`lTkt:_a_' );
define( 'SECURE_AUTH_SALT', 'sS?{q&MCcQv!} *..s6##@,rg?H)uRH?m3F(>)GNS_,1mvCY=|LItm_u<oO^*V^J' );
define( 'LOGGED_IN_SALT',   'MhT69TLC!n`;4,;v$RFg3rK~ZYQ][Sq|8`(.=e!WWk4fbR+Dj#0R@nzB3j|xP-s.' );
define( 'NONCE_SALT',       'R[]q 8z+pEx;b.$)M>&hY7S Z=_d*~9&L+BdPg%O;o%i>383q}dIB)s$r>IvzaYt' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
