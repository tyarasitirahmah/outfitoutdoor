document.addEventListener("DOMContentLoaded", function(){ window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-e56f7529' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-b95520ca' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-dea81880' );
});
window.addEventListener("DOMContentLoaded", function(){
	UAGBForms.init( {"block_id":"e702f682","reCaptchaEnable":false,"reCaptchaType":"v2","reCaptchaSiteKeyV2":"","reCaptchaSecretKeyV2":"","reCaptchaSiteKeyV3":"","reCaptchaSecretKeyV3":"","afterSubmitToEmail":"tiarasirirahmah@gmail.com","afterSubmitCcEmail":"","afterSubmitBccEmail":"","afterSubmitEmailSubject":"Pengiriman Formulir","sendAfterSubmitEmail":true,"confirmationType":"message","hidereCaptchaBatch":false,"captchaMessage":"Silakan isi captcha di atas.","confirmationUrl":""}, '.uagb-block-e702f682', 1113 );
});
 });