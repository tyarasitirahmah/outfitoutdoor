<?php

/*-----------------------------------------------------------------------------------*/
/*  Add Image Resize
/*-----------------------------------------------------------------------------------*/
locate_template( AUXIN_INC. 'modules/lib/aq-resizer.php', true, true );

/*-----------------------------------------------------------------------------------*/
/*  Include the TGM_Plugin_Activation class
/*-----------------------------------------------------------------------------------*/
locate_template( AUXIN_INC. 'modules/lib/class-tgm-plugin-activation.php' , true, true );
