<?php
namespace MailPoetVendor\Carbon\Exceptions;
if (!defined('ABSPATH')) exit;
use RuntimeException as BaseRuntimeException;
final class EndLessPeriodException extends BaseRuntimeException implements RuntimeException
{
 //
}
