<?php
namespace MailPoetVendor\Carbon\Exceptions;
if (!defined('ABSPATH')) exit;
use InvalidArgumentException as BaseInvalidArgumentException;
class UnitException extends BaseInvalidArgumentException implements InvalidArgumentException
{
 //
}
