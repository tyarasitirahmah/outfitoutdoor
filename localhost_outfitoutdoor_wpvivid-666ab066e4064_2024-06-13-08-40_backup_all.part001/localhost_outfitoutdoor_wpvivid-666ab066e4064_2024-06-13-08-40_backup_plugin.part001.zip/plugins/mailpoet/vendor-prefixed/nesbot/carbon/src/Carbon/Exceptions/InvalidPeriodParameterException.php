<?php
namespace MailPoetVendor\Carbon\Exceptions;
if (!defined('ABSPATH')) exit;
use InvalidArgumentException as BaseInvalidArgumentException;
class InvalidPeriodParameterException extends BaseInvalidArgumentException implements InvalidArgumentException
{
 //
}
