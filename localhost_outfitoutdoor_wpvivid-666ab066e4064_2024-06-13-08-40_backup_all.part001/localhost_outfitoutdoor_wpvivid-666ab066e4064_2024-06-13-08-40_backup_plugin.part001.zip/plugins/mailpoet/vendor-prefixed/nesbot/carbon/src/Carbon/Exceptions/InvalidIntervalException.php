<?php
namespace MailPoetVendor\Carbon\Exceptions;
if (!defined('ABSPATH')) exit;
use InvalidArgumentException as BaseInvalidArgumentException;
class InvalidIntervalException extends BaseInvalidArgumentException implements InvalidArgumentException
{
 //
}
