<?php
namespace MailPoetVendor\Carbon\Exceptions;
if (!defined('ABSPATH')) exit;
use InvalidArgumentException as BaseInvalidArgumentException;
class InvalidPeriodDateException extends BaseInvalidArgumentException implements InvalidArgumentException
{
 //
}
