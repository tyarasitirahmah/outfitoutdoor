<?php
namespace MailPoetVendor\Carbon\Exceptions;
if (!defined('ABSPATH')) exit;
use RuntimeException as BaseRuntimeException;
class UnreachableException extends BaseRuntimeException implements RuntimeException
{
 //
}
