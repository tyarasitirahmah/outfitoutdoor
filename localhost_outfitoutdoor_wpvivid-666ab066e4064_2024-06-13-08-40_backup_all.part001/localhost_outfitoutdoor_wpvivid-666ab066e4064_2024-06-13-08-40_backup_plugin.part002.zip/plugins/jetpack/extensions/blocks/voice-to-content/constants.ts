export const JETPACK_VOICE_TO_CONTENT_EXTENSION = 'voice-to-content' as const;
