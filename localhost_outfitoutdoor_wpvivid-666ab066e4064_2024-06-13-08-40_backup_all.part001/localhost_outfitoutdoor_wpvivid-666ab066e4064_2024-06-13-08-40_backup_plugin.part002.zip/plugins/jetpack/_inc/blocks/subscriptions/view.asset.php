<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'f691446bc9af9d5a18bd');
