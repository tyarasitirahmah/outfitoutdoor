<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'f23ee73c32d50167f7be');
