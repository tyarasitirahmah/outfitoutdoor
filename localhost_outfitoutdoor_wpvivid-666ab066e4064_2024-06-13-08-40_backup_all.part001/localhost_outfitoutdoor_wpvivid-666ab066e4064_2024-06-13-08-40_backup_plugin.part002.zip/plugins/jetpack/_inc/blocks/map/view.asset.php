<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '45be2e0556d013b531aa');
