<?php return array('dependencies' => array('wp-polyfill'), 'version' => '2b64c95728acee53dd11');
