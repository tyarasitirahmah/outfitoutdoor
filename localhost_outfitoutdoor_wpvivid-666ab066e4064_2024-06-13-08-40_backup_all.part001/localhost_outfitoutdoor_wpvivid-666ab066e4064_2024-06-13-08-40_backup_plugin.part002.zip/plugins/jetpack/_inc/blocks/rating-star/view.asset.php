<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'ab739a9752b5735a0ad1');
