<?php return array('dependencies' => array('wp-polyfill'), 'version' => '5c24c0cdf64cd8368a08');
