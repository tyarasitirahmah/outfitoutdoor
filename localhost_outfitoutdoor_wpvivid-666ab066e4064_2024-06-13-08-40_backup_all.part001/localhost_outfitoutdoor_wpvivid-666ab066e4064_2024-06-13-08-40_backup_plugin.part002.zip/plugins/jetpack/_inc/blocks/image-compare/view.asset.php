<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'f3ba866ed9b51d74d99f');
