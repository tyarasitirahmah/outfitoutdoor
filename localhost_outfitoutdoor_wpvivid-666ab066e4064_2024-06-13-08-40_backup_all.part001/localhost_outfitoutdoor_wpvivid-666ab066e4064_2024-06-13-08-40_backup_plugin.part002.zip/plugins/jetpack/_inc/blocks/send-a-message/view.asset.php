<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'ecc3d3265ff0117eee7b');
