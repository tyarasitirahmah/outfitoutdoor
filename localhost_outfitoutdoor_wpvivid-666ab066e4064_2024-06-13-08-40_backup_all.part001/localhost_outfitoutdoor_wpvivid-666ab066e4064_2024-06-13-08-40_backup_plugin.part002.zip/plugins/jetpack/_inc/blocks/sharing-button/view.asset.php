<?php return array('dependencies' => array('wp-polyfill'), 'version' => '86fe516550c4ae6475fe');
