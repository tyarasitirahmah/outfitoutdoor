<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '9b24295592dfed97f278');
