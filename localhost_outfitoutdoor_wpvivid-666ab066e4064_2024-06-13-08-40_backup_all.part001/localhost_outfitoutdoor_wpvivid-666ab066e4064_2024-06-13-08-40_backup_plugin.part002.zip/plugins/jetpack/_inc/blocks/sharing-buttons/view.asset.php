<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '1769f9e2d0237d2e1558');
