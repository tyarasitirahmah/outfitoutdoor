<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '973bcececc71d05de467');
