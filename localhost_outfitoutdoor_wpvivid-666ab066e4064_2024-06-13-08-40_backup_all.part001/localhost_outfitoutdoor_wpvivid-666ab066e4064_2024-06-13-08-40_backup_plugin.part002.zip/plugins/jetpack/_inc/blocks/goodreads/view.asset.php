<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'a7c372dc3714bccf1589');
