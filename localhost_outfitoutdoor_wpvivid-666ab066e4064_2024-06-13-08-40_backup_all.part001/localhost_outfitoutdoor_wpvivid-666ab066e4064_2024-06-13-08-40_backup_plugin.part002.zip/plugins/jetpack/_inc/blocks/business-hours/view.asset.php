<?php return array('dependencies' => array('wp-polyfill'), 'version' => '7b9b13c9b0dc24c6350e');
