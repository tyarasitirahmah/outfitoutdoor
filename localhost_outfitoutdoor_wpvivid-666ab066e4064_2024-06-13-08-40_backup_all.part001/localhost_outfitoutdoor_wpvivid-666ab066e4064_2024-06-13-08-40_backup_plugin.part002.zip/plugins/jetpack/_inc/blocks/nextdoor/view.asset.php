<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'f45cb2ca17fefb71e0c3');
